import React from 'react';
import { NavLink } from 'react-router-dom';

export default function Navbar(){
  return (
    <header>
      <a className="brand" href="/">
        <div className="logo">NF</div>
        <div>
          <strong>Nuel Foundation</strong>
        </div>
      </a>
      <nav>
        <NavLink to="/">Home</NavLink>
        <NavLink to="/about">About</NavLink>
        <NavLink to="/programs">Programs</NavLink>
        <NavLink to="/gallery">Gallery</NavLink>
        <NavLink to="/donate">Donate</NavLink>
        <NavLink to="/contact">Contact</NavLink>
      </nav>
    </header>
  );
}