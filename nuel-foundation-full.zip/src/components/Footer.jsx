import React from 'react';

export default function Footer(){
  return (
    <footer>
      © {new Date().getFullYear()} Nuel Foundation — Let love overshadow your heart to help.
    </footer>
  );
}