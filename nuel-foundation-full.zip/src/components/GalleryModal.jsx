import React from 'react';

export default function GalleryModal({open, image, title, onClose}){
  if(!open) return null;
  return (
    <div style={{
      position:'fixed', inset:0, background:'rgba(0,0,0,0.5)',
      display:'flex', justifyContent:'center', alignItems:'center'
    }} onClick={(e)=> e.target===e.currentTarget && onClose()}>
      <div style={{background:'#fff', padding:20, borderRadius:10, maxWidth:500}}>
        <h3>{title}</h3>
        <img src={image} alt={title} style={{width:'100%', borderRadius:10}} />
        <button onClick={onClose} style={{marginTop:10}}>Close</button>
      </div>
    </div>
  );
}