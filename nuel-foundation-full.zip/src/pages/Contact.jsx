import React, {useState} from 'react';

export default function Contact(){
  const [status, setStatus] = useState('');

  function submit(e){
    e.preventDefault();
    setStatus('Sent!');
  }

  return (
    <div className="card">
      <h2>Contact</h2>
      <form onSubmit={submit}>
        <input placeholder="Name" required />
        <input placeholder="Email" required />
        <textarea placeholder="Message" required />
        <button className="btn">Send</button>
      </form>
      <p>{status}</p>
    </div>
  );
}