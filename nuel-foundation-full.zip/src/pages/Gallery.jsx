import React, {useState} from 'react';
import GalleryModal from '../components/GalleryModal';

export default function Gallery(){
  const [open, setOpen] = useState(false);
  const [img, setImg] = useState('');
  const [title, setTitle] = useState('');

  const images = [
    {src:'/gallery-1.jpg', alt:'Outreach 1'},
    {src:'/gallery-2.jpg', alt:'Outreach 2'},
    {src:'/gallery-3.jpg', alt:'Outreach 3'}
  ];

  function openModal(i){
    setImg(i.src); setTitle(i.alt); setOpen(true);
  }

  return (
    <div className="card">
      <h2>Gallery</h2>
      <div className="gallery">
        {images.map((i, idx)=> (
          <img key={idx} src={i.src} alt={i.alt} onClick={()=>openModal(i)} />
        ))}
      </div>
      <GalleryModal open={open} image={img} title={title} onClose={()=>setOpen(false)} />
    </div>
  );
}