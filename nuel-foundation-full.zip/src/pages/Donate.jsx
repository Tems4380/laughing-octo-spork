import React from 'react';

export default function Donate(){
  return (
    <div className="card">
      <h2>Donate</h2>
      <p>Support our programs.</p>
      <p><strong>Account Name:</strong> Emmanuel Adigun Ayodeji</p>
      <p><strong>Account Number:</strong> 2032401316</p>
    </div>
  );
}