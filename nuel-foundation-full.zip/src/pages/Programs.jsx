import React from 'react';

export default function Programs(){
  return (
    <div className="card">
      <h2>Programs</h2>
      <ul>
        <li>Orphanage Care</li>
        <li>Youth Empowerment</li>
        <li>Healthcare Aid</li>
      </ul>
    </div>
  );
}