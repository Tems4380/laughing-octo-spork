import React from 'react';

export default function About(){
  return (
    <div className="card">
      <h2>About Nuel Foundation</h2>
      <p>Nuel Foundation was founded by Emmanuel Adigun Ayodeji...</p>
    </div>
  );
}