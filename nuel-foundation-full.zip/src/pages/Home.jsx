import React from 'react';
import { Link } from 'react-router-dom';

export default function Home(){
  return (
    <section className="hero">
      <h1>We care for orphans & empower children and youth.</h1>
      <p>Nuel Foundation focuses on orphanage support, empowerment, education and community support.</p>
      <Link className="btn" to="/donate">Donate Now</Link>
    </section>
  );
}